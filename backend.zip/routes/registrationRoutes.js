import express from 'express';
import Registration from '../models/Registration.js';

const router = express.Router();

// POST route to save registration data
router.post('/', async (req, res) => {
    const { 
        name, 
        registrationNo, 
        email, 
        phone, 
        razorpay_payment_id, 
        razorpay_order_id, 
        razorpay_signature 
    } = req.body;

    // Validate required fields
    if (!name || !registrationNo || !email || !phone ||
        !razorpay_payment_id || !razorpay_order_id || !razorpay_signature) {
        return res.status(400).json({ error: 'All fields are required' });
    }

    try {
        const newRegistration = new Registration({
            name,
            registrationNo,
            email,
            phone,
            razorpay_payment_id,
            razorpay_order_id,
            razorpay_signature,
        });

        await newRegistration.save();
        res.status(201).json("Registration successful");
    } catch (err) {
        console.error(err.message);
        res.status(500).send('Server Error');
    }
});

export default router;