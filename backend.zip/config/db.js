import mongoose from 'mongoose';

const connectDB = async () => {
    try {
        await mongoose.connect("mongodb+srv://metahack:2024MetaHack2023@macbease-hackthon-25-20.frnwm.mongodb.net/?retryWrites=true&w=majority&appName=macbease-hackthon-25-2024");
        console.log('MongoDB Connected...');
    } catch (err) {
        console.error(err.message);
        process.exit(1);
    }
};

export default connectDB;
