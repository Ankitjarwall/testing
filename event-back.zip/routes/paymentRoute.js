import express from "express";
import Razorpay from "razorpay";
import axios from "axios";
import crypto from "crypto";
import dotenv from "dotenv";
dotenv.config();

const router = express.Router();

const razorpay = new Razorpay({
    key_id: process.env.RAZORPAY_ID_KEY,
    key_secret: process.env.RAZORPAY_SECRET_KEY,
});

// Rotue to create new order for payment
router.post("/order", async (req, res) => {
    try {
        const options = {
            amount: 14900, // 149 rupees in paise
            currency: "INR",
            receipt: `receipt_${Date.now()}`,
        };
        const order = await razorpay.orders.create(options);
        res.status(200).json({ success: true, order });     // success if order is created
    } catch (error) {
        console.error("Error creating Razorpay order:", error);
        res.status(500).json({
            success: false,
            message: "Failed to create order",   // failure if order is not created
        });
    }
});

// Route to verify payment status
router.post("/verify-payment", (req, res) => {
    const { order_id, payment_id, signature, memberDetails } = req.body;

    const hash = crypto
        .createHmac("sha256", process.env.RAZORPAY_SECRET_KEY)
        .update(`${order_id}|${payment_id}`)
        .digest("hex");

    memberDetails.razorpay_payment_id = payment_id;
    memberDetails.razorpay_order_id = order_id;
    memberDetails.razorpay_signature = signature;

    if (hash === signature) {
        axios
            .post(`${process.env.BACKEND_URL}/api/register`, memberDetails)
            .then(() => {
                res.status(200).json({
                    success: true,
                    message: "Registration successful",
                });
            })
            .catch((error) => {
                console.error("Error saving registration data:", error);
                res.status(500).json({
                    success: false,
                    message: "Failed to save registration data",
                });
            });
    } else {
        console.error("Payment verification failed");
        res.status(400).json({ success: false, message: "Invalid signature" });
    }
});

export default router;
