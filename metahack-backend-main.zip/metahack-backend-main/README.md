## **Installation**

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd <repository-folder>
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Create a `.env` file in the root directory and add the following:
   ```env
   PORT=5000
   MONGO_URI=mongodb://localhost:27017/registrationDB
   ```

4. Start the server:
   ```bash
   npm start
   ```

---

## **API Endpoints**

### **Base URL**
```
http://localhost:5000
```

### **POST /api/register**

#### **Request**
- **URL**: `/api/register`
- **Method**: `POST`
- **Headers**:
  - `Content-Type: application/json`
- **Body (JSON)**:
  ```json
  {
      "teamName": "team name",
      "memberName": "member name",
      "registrationNo": "registration number",
      "email": "email",
      "phone": "phone no",
      "razorpay_payment_id": "payment id",
      "razorpay_order_id": "order id",
      "razorpay_signature": "signature"
  }
  ```

#### **Response**
- **Success (201 Created)**:
  ```json
  {
    "message": "Registration successful",
  }
  ```

- **Error (400 Bad Request)**:
  ```json
  {
      "error": "All fields are required"
  }
  ```

- **Error (500 Server Error)**:
  ```json
  {
      "error": "Server Error"
  }
  ```

---