import mongoose from 'mongoose';

const RegistrationSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    registrationNo: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        match: /.+\@.+\..+/,
    },
    phone: {
        type: String,
        required: true,
    },
    razorpay_payment_id: {
        type: String,
        required: true,
    },
    razorpay_order_id: {
        type: String,
        required: true,
    },
    razorpay_signature: {
        type: String,
        required: true,
    },
}, { timestamps: true });

const Registration = mongoose.model('Registration', RegistrationSchema);
export default Registration;